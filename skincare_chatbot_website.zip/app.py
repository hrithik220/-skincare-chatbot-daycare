from flask import Flask, render_template, request

app = Flask(__name__)

skincare_data = {
    "normal": {
        "cleanser": "Gentle foaming cleanser",
        "toner": "Alcohol-free hydrating toner",
        "serum": "Vitamin C serum for glow",
        "moisturizer": "Lightweight cream moisturizer",
        "sunscreen": "SPF 30+ broad-spectrum sunscreen (any texture)"
    },
    "dry": {
        "cleanser": "Cream-based hydrating cleanser",
        "toner": "Hydrating toner with hyaluronic acid",
        "serum": "Hyaluronic acid or glycerin serum",
        "moisturizer": "Thick, ceramide-rich moisturizer",
        "sunscreen": "Moisturizing SPF 50 sunscreen (cream-based)"
    },
    "oily": {
        "cleanser": "Gel cleanser with salicylic acid",
        "toner": "BHA toner (salicylic acid) – alcohol-free",
        "serum": "Niacinamide serum (oil-control)",
        "moisturizer": "Oil-free, gel-based moisturizer",
        "sunscreen": "Mattifying SPF 50 gel sunscreen"
    },
    "combination": {
        "cleanser": "Gentle gel cleanser",
        "toner": "Hydrating + mild exfoliating toner",
        "serum": "Niacinamide or Vitamin C serum",
        "moisturizer": "Balancing, non-comedogenic moisturizer",
        "sunscreen": "SPF 50 with non-greasy texture"
    },
    "sensitive": {
        "cleanser": "Fragrance-free cream cleanser",
        "toner": "Calming toner with Centella or Aloe Vera",
        "serum": "Panthenol or Centella serum",
        "moisturizer": "Barrier-repair moisturizer (ceramides)",
        "sunscreen": "Mineral SPF 50 (zinc oxide or titanium dioxide)"
    },
    "acne-prone": {
        "cleanser": "Salicylic acid cleanser",
        "toner": "Witch hazel or BHA toner",
        "serum": "Niacinamide or Tea Tree serum",
        "moisturizer": "Non-comedogenic gel moisturizer",
        "sunscreen": "Oil-free, acne-safe SPF 50 gel"
    }
}

avoid_ingredients = {
    "dry": "Avoid alcohol-based products, strong acids.",
    "oily": "Avoid heavy oils like coconut oil, lanolin.",
    "sensitive": "Avoid fragrance, alcohol, essential oils.",
    "acne-prone": "Avoid comedogenic oils and thick creams.",
    "normal": "Avoid unnecessary exfoliants or over-cleansing.",
    "combination": "Avoid harsh products that can over-dry some areas."
}

@app.route("/", methods=["GET", "POST"])
def index():
    result = {}
    if request.method == "POST":
        skin_type = request.form.get("skin_type")
        option = request.form.get("option")
        routine = skincare_data.get(skin_type, {})
        tips = "Always reapply SPF every 2-3 hours when outdoors."
        products = "Try brands like CeraVe, Neutrogena, Minimalist, Biore."
        avoid = avoid_ingredients.get(skin_type, "No specific info.")

        result = {
            "skin_type": skin_type,
            "routine": routine,
            "tips": tips if option == "tips" else None,
            "products": products if option == "products" else None,
            "avoid": avoid if option == "avoid" else None
        }
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
